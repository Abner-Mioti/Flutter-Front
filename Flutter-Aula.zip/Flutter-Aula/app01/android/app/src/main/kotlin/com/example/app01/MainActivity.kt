package com.example.app01

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
