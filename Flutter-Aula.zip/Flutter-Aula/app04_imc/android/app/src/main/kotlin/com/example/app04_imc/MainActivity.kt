package com.example.app04_imc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
