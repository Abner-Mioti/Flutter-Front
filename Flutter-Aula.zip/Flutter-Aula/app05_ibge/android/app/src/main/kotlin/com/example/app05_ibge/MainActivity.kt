package com.example.app05_ibge

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
