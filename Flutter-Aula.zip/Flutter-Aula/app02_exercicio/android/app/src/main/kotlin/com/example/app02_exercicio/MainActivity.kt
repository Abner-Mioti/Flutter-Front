package com.example.app02_exercicio

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
